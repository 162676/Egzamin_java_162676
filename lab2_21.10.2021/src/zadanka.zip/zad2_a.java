import java.util.Random;
public class zad2_a {
    public static void generuj(int []list, int n,int minWartosc,int maxWartosc) {
        Random generator = new Random();
        for(int i=0; i<n;i++)
        {
            list[i] =  generator.nextInt (maxWartosc+1+maxWartosc)+minWartosc;

            System.out.println(list[i]);
        }
    }
    public static void main(String[] args) {
        int list[] =
        generuj(list,5,-999,999);
    }
}
