public class zad3 {
    public static void main(String[] args) {

    }
}
